# App Flow Document
## Job Portal — Two-Sided Marketplace

**Version:** 1.0
**Status:** Draft for review

---

## 1. Onboarding Flow

```
Landing Page
   │
   ▼
"Sign Up" → Choose Role: [Job Seeker] or [Employer]
   │
   ├── Job Seeker → Enter name/email/password → Verify email → Build profile
   │                 (skills, experience, resume upload) → Dashboard
   │
   └── Employer   → Enter name/email/password → Verify email → Build company
                     profile (name, logo, description, website) → Dashboard
```

## 2. Job Seeker Flow

```
Login → Seeker Dashboard
   │
   ├── Browse Jobs → Search/Filter (keyword, location, category, salary)
   │       │
   │       ▼
   │    Job Detail Page → "Apply" → Attach resume + cover letter → Submit
   │       │
   │       ▼
   │    Confirmation → Application appears in "My Applications"
   │
   ├── My Applications → View status (Applied / In Review / Interview / Rejected / Hired)
   │
   ├── Saved Jobs → Bookmarked listings
   │
   └── Profile → Edit bio, skills, resume, experience
```

## 3. Employer Flow

```
Login → Employer Dashboard
   │
   ├── Post a Job → Fill form (title, description, requirements, salary,
   │                 location, job type) → Publish
   │
   ├── Manage Jobs → List of posted jobs → [Edit] [Close] [View Applicants]
   │       │
   │       ▼
   │    Applicants List (per job) → View candidate profile/resume
   │       │
   │       ▼
   │    Update Status (In Review / Interview / Rejected / Hired) → Seeker notified
   │
   └── Company Profile → Edit company info/logo
```

## 4. Admin Flow (if included in v1)

```
Admin Login → Admin Dashboard
   │
   ├── Review Pending Job Postings → Approve / Reject
   ├── Manage Users → Suspend / Reinstate
   └── Platform Stats → Users, jobs, applications overview
```

## 5. Notification Triggers
| Event | Notified User | Channel |
|---|---|---|
| New application received | Employer | Email + in-app |
| Application status changed | Job Seeker | Email + in-app |
| Job approved/rejected (if moderated) | Employer | Email |
| Account verification | New user | Email |

## 6. Navigation Map (top-level)
- **Public:** Home, Browse Jobs, Job Detail, Login, Sign Up
- **Seeker (authenticated):** Dashboard, Browse Jobs, My Applications, Saved Jobs, Profile
- **Employer (authenticated):** Dashboard, Post Job, Manage Jobs, Applicants, Company Profile
- **Admin (authenticated):** Admin Dashboard, Job Moderation, User Management

---
**Next document:** UI/UX Design
