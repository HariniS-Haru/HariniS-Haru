# Backend Schema Document
## Job Portal — Two-Sided Marketplace

**Version:** 1.0
**Status:** Draft for review

---

## 1. Entity Relationship Overview

```
User (1) ──< (1) SeekerProfile
User (1) ──< (1) Company (employer owner)
Company (1) ──< (M) Job
User[seeker] (1) ──< (M) Application
Job (1) ──< (M) Application
User (1) ──< (M) SavedJob >── (1) Job
```

## 2. Core Tables (Prisma-style schema)

### 2.1 User
```prisma
model User {
  id            String   @id @default(uuid())
  email         String   @unique
  passwordHash  String
  role          Role     // SEEKER | EMPLOYER | ADMIN
  isVerified    Boolean  @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  seekerProfile SeekerProfile?
  company       Company?
  applications  Application[]
  savedJobs     SavedJob[]
}

enum Role {
  SEEKER
  EMPLOYER
  ADMIN
}
```

### 2.2 SeekerProfile
```prisma
model SeekerProfile {
  id          String   @id @default(uuid())
  userId      String   @unique
  user        User     @relation(fields: [userId], references: [id])
  fullName    String
  headline    String?
  bio         String?
  skills      String[]
  resumeUrl   String?
  experience  Json?    // array of {title, company, startDate, endDate, description}
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
```

### 2.3 Company
```prisma
model Company {
  id          String   @id @default(uuid())
  ownerId     String   @unique
  owner       User     @relation(fields: [ownerId], references: [id])
  name        String
  logoUrl     String?
  description String?
  website     String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  jobs        Job[]
}
```

### 2.4 Job
```prisma
model Job {
  id            String    @id @default(uuid())
  companyId     String
  company       Company   @relation(fields: [companyId], references: [id])
  title         String
  description   String
  requirements  String?
  category      String
  location      String
  jobType       JobType   // FULL_TIME | PART_TIME | CONTRACT | INTERNSHIP | REMOTE
  salaryMin     Int?
  salaryMax     Int?
  status        JobStatus @default(ACTIVE) // ACTIVE | CLOSED | PENDING_REVIEW
  postedAt      DateTime  @default(now())
  closedAt      DateTime?

  applications  Application[]
  savedBy       SavedJob[]

  @@index([category, location, status])
}

enum JobType {
  FULL_TIME
  PART_TIME
  CONTRACT
  INTERNSHIP
  REMOTE
}

enum JobStatus {
  ACTIVE
  CLOSED
  PENDING_REVIEW
}
```

### 2.5 Application
```prisma
model Application {
  id            String            @id @default(uuid())
  jobId         String
  job           Job               @relation(fields: [jobId], references: [id])
  seekerId      String
  seeker        User              @relation(fields: [seekerId], references: [id])
  resumeUrl     String
  coverLetter   String?
  status        ApplicationStatus @default(APPLIED)
  appliedAt     DateTime          @default(now())
  updatedAt     DateTime          @updatedAt

  @@unique([jobId, seekerId])
}

enum ApplicationStatus {
  APPLIED
  IN_REVIEW
  INTERVIEW
  REJECTED
  HIRED
}
```

### 2.6 SavedJob
```prisma
model SavedJob {
  id        String   @id @default(uuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id])
  jobId     String
  job       Job      @relation(fields: [jobId], references: [id])
  savedAt   DateTime @default(now())

  @@unique([userId, jobId])
}
```

### 2.7 Notification
```prisma
model Notification {
  id        String   @id @default(uuid())
  userId    String
  type      String   // APPLICATION_STATUS_CHANGE | NEW_APPLICANT | etc.
  message   String
  isRead    Boolean  @default(false)
  createdAt DateTime @default(now())
}
```

## 3. Indexing Strategy
- `Job(category, location, status)` — composite index for search/filter performance
- `Application(jobId, seekerId)` — unique constraint + lookup index
- `User(email)` — unique index for login

## 4. Data Integrity Rules
- A seeker can apply to a given job only once (`@@unique([jobId, seekerId])`)
- Deleting a `User` cascades review (soft-delete recommended instead of hard delete, to preserve application history)
- `Job.status = CLOSED` should stop accepting new applications at the API layer

---
**Next document:** Implementation Plan
