# Technical Requirements Document (TRD)
## Job Portal — Two-Sided Marketplace

**Version:** 1.0
**Status:** Draft for review

---

## 1. Recommended Tech Stack

| Layer | Technology | Why |
|---|---|---|
| Frontend | **Next.js (React) + TypeScript** | SSR/SEO for job listings, fast dev, one codebase for pages + API routes |
| Styling | **Tailwind CSS** | Fast, consistent UI development |
| Backend | **Next.js API routes** (or standalone Node/Express if scale demands) | Keeps stack unified for v1; can split out later |
| Database | **PostgreSQL** | Relational data (users, jobs, applications) fits well; strong querying/filtering |
| ORM | **Prisma** | Type-safe DB access, easy migrations |
| Auth | **JWT + bcrypt** (or NextAuth.js) | Secure, standard session handling |
| File Storage | **AWS S3 / Cloudflare R2** | Resume & logo uploads |
| Email | **Resend / SendGrid** | Verification & notification emails |
| Hosting | **Vercel** (frontend/API) + **Railway/Supabase** (Postgres) | Simple CI/CD, low ops overhead |
| Search/Filter | Postgres full-text search (v1) → Algolia/Meilisearch (later) | Avoid overengineering early |

## 2. System Architecture (high-level)
```
Client (Next.js) 
   │
   ▼
Next.js API Routes (REST)
   │
   ├── Auth Service (JWT)
   ├── Jobs Service
   ├── Applications Service
   ├── Users/Company Service
   └── Notifications Service
   │
   ▼
PostgreSQL (via Prisma)
   │
   └── S3 (resumes, logos)
```

## 3. Non-Functional Requirements
- **Performance:** Job search results in <500ms for up to 100k listings (with proper indexing)
- **Security:** Password hashing (bcrypt), input validation, rate limiting on auth endpoints, RBAC (role-based access control)
- **Scalability:** Stateless API layer, DB read replicas if needed later
- **Availability:** Target 99.5% uptime for v1
- **Data Privacy:** Resumes/PII encrypted at rest; GDPR-style delete-my-data support

## 4. API Design Principles
- RESTful endpoints, versioned (`/api/v1/...`)
- JSON request/response
- Pagination via `limit`/`offset` or cursor-based for job listings
- Consistent error format: `{ error: { code, message } }`

## 5. Key API Endpoints (preview — full spec in Backend Schema doc)
- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/login`
- `GET /api/v1/jobs` (search/filter)
- `POST /api/v1/jobs` (employer only)
- `POST /api/v1/jobs/:id/apply`
- `GET /api/v1/applications` (role-aware: seeker sees own, employer sees per-job)
- `PATCH /api/v1/applications/:id/status`

## 6. Testing Strategy
- Unit tests: Jest (business logic, utils)
- Integration tests: API route testing (Supertest)
- E2E: Playwright (core flows — signup, post job, apply)

## 7. DevOps
- Git-based CI/CD (GitHub Actions → Vercel deploy)
- Environment separation: dev / staging / prod
- DB migrations via Prisma Migrate

## 8. Open Technical Risks
- Full-text search performance at scale (mitigation: move to Meilisearch when needed)
- File upload abuse (mitigation: file-type/size validation, virus scan if budget allows)

---
**Next document:** App Flow
