# Product Requirements Document (PRD)
## Job Portal — Two-Sided Marketplace

**Version:** 1.0
**Status:** Draft for review

---

## 1. Overview
A web-based job portal connecting **job seekers** and **employers**. Job seekers create profiles, search/apply to jobs, and track applications. Employers post jobs, manage listings, and review/manage applicants.

## 2. Goals
- Let employers post and manage job listings efficiently
- Let job seekers discover, filter, and apply to relevant jobs
- Provide a simple application-tracking workflow for both sides
- Build a scalable foundation that can grow (messaging, payments, premium listings later)

## 3. Non-Goals (v1)
- No resume-parsing AI/auto-matching (future phase)
- No in-app payments/subscriptions (future phase)
- No native mobile app (web-responsive only)

## 4. User Roles
| Role | Description |
|---|---|
| **Job Seeker** | Creates profile, uploads resume, searches/applies to jobs |
| **Employer** | Creates company profile, posts jobs, manages applicants |
| **Admin** | Moderates listings/users, manages platform |

## 5. Core Features

### 5.1 Authentication
- Sign up / login (email + password, role selection: seeker or employer)
- Password reset
- Email verification

### 5.2 Job Seeker Features
- Create/edit profile (bio, skills, experience, resume upload)
- Browse/search jobs (keyword, location, category, salary, job type)
- Filter & sort results
- Apply to jobs (resume + cover letter)
- Track application status (Applied, In Review, Interview, Rejected, Hired)
- Save/bookmark jobs

### 5.3 Employer Features
- Create/edit company profile
- Post/edit/close job listings
- View & manage applicants per job
- Update applicant status
- Basic analytics (views, applicant count per job)

### 5.4 Admin Features
- Approve/reject job postings (optional moderation)
- Manage/suspend users
- View platform-wide stats

### 5.5 Shared
- Notifications (email on application status change, new applicant)
- Search with pagination

## 6. Success Metrics
- # of active job seekers / employers
- # of jobs posted per week
- Application completion rate
- Time-to-fill (avg days a job stays open before being closed)

## 7. Assumptions & Constraints
- English-only for v1
- Single currency for salary display (configurable later)
- Resume uploads limited to PDF/DOCX, max 5MB

## 8. Future Considerations
- In-app messaging between employer & candidate
- Paid/featured job listings
- AI-based job matching
- Company reviews/ratings

---
**Next document:** Technical Requirements Document (TRD)
