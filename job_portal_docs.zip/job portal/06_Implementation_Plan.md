# Implementation Plan
## Job Portal — Two-Sided Marketplace

**Version:** 2.0 (Solo Developer + AI-Assisted)
**Status:** Draft for review

---

## Context
This plan assumes **one developer**, working in **VS Code**, using AI assistance (e.g., Claude/Copilot-style pair programming) for scaffolding, boilerplate, debugging, and code review. Timeline is paced realistically for solo work — AI speeds up writing code, but architecture decisions, testing, and integration still take real time.

## How AI Fits Into the Workflow
- **Scaffolding:** generate boilerplate (Prisma schema, API routes, form components) from the specs in this doc set
- **Code review:** paste diffs/files for a second pass on bugs, edge cases, security gaps
- **Debugging:** paste error messages/stack traces for faster root-causing
- **Test writing:** generate Jest/Playwright test skeletons, then refine
- **Docs → code:** feed sections of the PRD/TRD/Backend Schema directly as prompts when building each feature, so output stays aligned with the spec

Recommended VS Code setup: Git integration, REST client or Thunder Client (API testing), Prisma extension, ESLint + Prettier, an AI coding extension of choice.

---

## Phase 0: Project Setup (Days 1–2)
- Init Next.js + TypeScript project, configure Tailwind
- Set up PostgreSQL (local via Docker, or free-tier hosted like Supabase/Neon)
- Configure Prisma, run first migration
- Set up Git repo + basic GitHub Actions CI (lint + build check)
- Use AI to scaffold folder structure and config files

## Phase 1: Auth & User Foundations (Days 3–7)
- `User` model + migration
- Signup/login (role selection: seeker/employer), password hashing, JWT
- Email verification flow (use a simple provider like Resend)
- AI-assist: generate auth route handlers and validation logic, then review/harden manually (this is the most security-sensitive phase — review AI output carefully)

## Phase 2: Profiles (Days 8–12)
- `SeekerProfile` and `Company` models + migrations
- Seeker profile create/edit, resume upload (S3 or Cloudflare R2)
- Employer/company profile create/edit, logo upload
- Profile completeness indicator

## Phase 3: Job Posting & Search (Days 13–19)
- `Job` model + migration
- Employer: post/edit/close job (form + API)
- Job listing page: search, filters, pagination
- Job detail page
- Postgres full-text search + index on `category/location/status`
- AI-assist: generate filter/query-building logic, then test with sample data

## Phase 4: Applications (Days 20–25)
- `Application` model + migration
- Seeker: apply to job (resume + cover letter)
- Employer: view applicants per job, update status
- "My Applications" status tracking view
- Duplicate-application prevention (unique constraint)

## Phase 5: Notifications (Days 26–29)
- Email notifications (application received, status change, verification)
- In-app notification list + read/unread state
- `Notification` model + migration

## Phase 6: Dashboards & Polish (Days 30–35)
- Seeker dashboard (applications, saved jobs, profile status)
- Employer dashboard (active jobs, applicant summary)
- Saved/bookmarked jobs feature
- Empty states, loading states, error handling pass
- UI polish pass against the UI/UX Design doc

## Phase 7: Admin (Optional — Days 36–39)
- Admin dashboard: job moderation, user management, basic platform stats
- Skip for v1 launch if time-constrained; add post-launch

## Phase 8: QA & Launch Prep (Days 40–45)
- Unit tests (Jest) for core business logic — AI-generate skeletons, then fill in assertions
- Integration tests for key API routes
- E2E tests (Playwright) for signup → post job → apply → status update
- Accessibility pass (WCAG AA contrast, keyboard nav)
- Security review checklist: rate limiting, input validation, RBAC checks, resume upload validation
- Performance pass (search query speed, image/asset optimization)

## Phase 9: Launch (Days 46–48)
- Production deploy (Vercel + hosted Postgres)
- Basic monitoring/error tracking (Sentry free tier)
- Soft launch → gather feedback → iterate

---

## Realistic Timeline
**~7–8 weeks** working part-time-to-full-time as a solo developer with AI assistance, assuming no major scope changes. This is roughly 2–3x faster than an unassisted solo build, but slower than a small team, since one person still has to context-switch between frontend, backend, and QA.

## Solo-Dev Risk Notes
- **Biggest time sink:** integration/debugging across the stack, not writing individual features — budget slack time each week for this
- **Security-sensitive code (auth, file uploads, payment-adjacent logic later)** should always get a manual review pass, not just AI-generated and shipped
- **Scope discipline:** as a solo builder, resist adding features mid-phase (e.g., messaging, payments) — stick to the PRD's v1 scope and log extras for "Future Considerations"

## Milestone Summary
| Milestone | Target (working day) |
|---|---|
| Auth + Profiles working | Day 12 |
| Jobs postable & searchable | Day 19 |
| Full application flow working | Day 25 |
| Feature-complete for QA | Day 39 |
| Launch-ready | Day 48 |

---
*This is the final document in the set (PRD → TRD → App Flow → UI/UX Design → Backend Schema → Implementation Plan).*
