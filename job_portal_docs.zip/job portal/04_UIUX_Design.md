# UI/UX Design Document
## Job Portal — Two-Sided Marketplace

**Version:** 1.0
**Status:** Draft for review

---

## 1. Design Principles
- **Clarity first** — job seekers and employers should complete core tasks (find a job / post a job) in as few steps as possible
- **Trust & credibility** — clean, professional visual tone (this is where people manage their careers/hiring)
- **Consistency** — one shared design system across both seeker and employer experiences
- **Responsive** — mobile-first, since many seekers will browse on phones

## 2. Design System

| Element | Choice |
|---|---|
| Primary color | Deep blue (#1E3A8A) — trust, professionalism |
| Accent color | Teal/green (#0D9488) — for CTAs, success states |
| Neutral palette | Slate grays (#F8FAFC → #0F172A) |
| Typography | Inter or similar geometric sans-serif |
| Corner radius | Medium (8px) — modern but not overly playful |
| Spacing | 8px base grid |
| Components | Cards (job listings), pill tags (skills/categories), status badges (application stages) |

## 3. Key Screens

### 3.1 Home / Landing Page
- Hero search bar (keyword + location)
- Featured/recent jobs grid
- CTA split: "Find a Job" / "Post a Job"

### 3.2 Job Search / Browse
- Left sidebar: filters (category, location, job type, salary range)
- Main area: job cards (title, company logo, location, salary, posted date)
- Top bar: sort (relevance, newest, salary)
- Pagination or infinite scroll

### 3.3 Job Detail Page
- Header: title, company, location, salary, job type, "Apply" button (sticky on scroll)
- Body: description, requirements, benefits
- Sidebar: company mini-profile, "similar jobs"

### 3.4 Apply Modal/Page
- Resume upload (or select from saved)
- Cover letter (optional text field)
- Review & submit

### 3.5 Seeker Dashboard
- Summary cards: applications sent, saved jobs, profile completeness
- Recent application status list
- Quick links to browse jobs / edit profile

### 3.6 Employer Dashboard
- Summary cards: active jobs, total applicants, new applicants this week
- Job list table (status, applicant count, posted date) with quick actions

### 3.7 Post a Job Form
- Multi-step or single scrollable form: Basics → Description → Requirements → Compensation → Review
- Live preview panel (optional, v2)

### 3.8 Applicant Management (Employer)
- Kanban-style or list view of applicants per job
- Columns/status: Applied → In Review → Interview → Rejected/Hired
- Click applicant → side panel with resume preview + status changer

### 3.9 Profile Pages
- **Seeker:** photo, headline, bio, skills (tags), experience timeline, resume file
- **Employer:** logo, company name, description, website, open jobs list

## 4. Interaction Patterns
- Status changes reflected with color-coded badges (gray = applied, blue = in review, yellow = interview, green = hired, red = rejected)
- Toast notifications for actions (job posted, application submitted)
- Empty states designed for: no jobs found, no applications yet, no applicants yet

## 5. Accessibility
- WCAG AA color contrast minimum
- Keyboard-navigable forms and filters
- Alt text for company logos/images
- Form validation with clear inline error messaging

## 6. Responsive Behavior
- Filters collapse into a drawer/modal on mobile
- Job cards stack single-column on mobile
- Sticky "Apply" button remains accessible on mobile job detail view

---
**Next document:** Backend Schema
